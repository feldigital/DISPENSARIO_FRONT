export const environment = {
   production: true,
   //apiUrl: 'http://localhost:8080/api',
   //urlRecursos: 'http://localhost:8080',

   apiUrl: 'http://107.23.161.120:8080/api',
   urlRecursos: 'http://107.23.161.120:8080',
};
