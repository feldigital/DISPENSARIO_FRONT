import { Component } from '@angular/core';

@Component({
  selector: 'app-norotan',
  templateUrl: './norotan.component.html',
  styleUrls: ['./norotan.component.css']
})
export class NorotanComponent {

}
