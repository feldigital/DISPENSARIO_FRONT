export class IpsI {
    idIps: number;
    nit: String;
    codHabilitacion: String;
    nombre: String;
    estado: Boolean; 


    constructor() {
        this.idIps = NaN;
        this.nit = ""; 
        this.codHabilitacion = ""; 
        this.nombre = "";       
        this.estado = true;       
    }

}
