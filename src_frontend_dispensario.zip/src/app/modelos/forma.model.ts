
export class FormaI {
    idForma: number;
    nombre: String;
    estado: Boolean;	
  


    constructor() {
        this.idForma = NaN;
        this.nombre = "";       
        this.estado = true;       
      
    }

}
