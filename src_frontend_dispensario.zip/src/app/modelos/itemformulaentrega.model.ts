
export class ItemFormulaEntregaI {
  idItemEntrega:number=NaN;
  cantidadEntregada: number = 1;
  medioEntrega: string='';
  funcionarioEntrega: string='';
  estado: boolean=true;
  fecEntrega= new Date(); 

}
