export class EpsMedicamentoI {
    id: number;
    idMedicamento: number;
    codEps: String;
    


    constructor() {
        this.id = NaN;
        this.idMedicamento = NaN;        
        this.codEps = "";                
    }

}
