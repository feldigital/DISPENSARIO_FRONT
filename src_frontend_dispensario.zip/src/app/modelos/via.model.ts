

export class ViaI {
    idVia: number;
    nombre: String;
    estado: Boolean;	
  


    constructor() {
        this.idVia = NaN;
        this.nombre = "";       
        this.estado = true;       
      
    }

}
